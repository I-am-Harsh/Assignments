import { Component, OnInit } from '@angular/core';
import { ListserviceService } from '../listservice.service';

@Component({
  selector: 'app-searchlist',
  templateUrl: './searchlist.component.html',
  styleUrls: ['./searchlist.component.css']
})




export class SearchlistComponent implements OnInit {

  constructor(private _list: ListserviceService) { }
  arr = [];

  visible : boolean = false;
  ngOnInit() {
    console.log(this.visible);
  }

  show() {
    this.visible = true
    console.log('invoked')
    this._list.getList()
      .subscribe(Data => this.arr = Data)
  }
}
