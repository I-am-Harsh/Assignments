import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { list } from './file'
// import {book } from './file'

@Injectable({
  providedIn: 'root'
})
export class ListserviceService {

  constructor(private http: HttpClient) { }
  private _url: string = "./assets/booklist.json";
  getList(): Observable<list[]> {
    return this.http.get<list[]>(this._url);
  }

}

// export class BookService {
//   private _jsonURL = 'assets/url';

//   constructor(private http: HttpClient){}

//   public getJSON(): Observable<Book[]>{
//     return this.http.get<Book[]>(this._jsonURL)
//   }
// }