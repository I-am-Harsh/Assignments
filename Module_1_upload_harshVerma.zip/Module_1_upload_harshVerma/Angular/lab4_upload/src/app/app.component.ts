import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Harsh Verma MPT Assignment';


  // constructor(private bookservice : BookService){}

// books : Book[] = [];
  // ngOnInit(){
  //   this.bookservice.getJSON().subscribe((data) => {
  //     this.books = data;
  //   })
  // }
}
