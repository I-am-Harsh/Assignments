var r=confirm("Press a button");
if(r==true)
    document.write("You pressed OK");
else{
    document.write("you pressed cancel");
}