package Lab_7;


// import java.collections.*;
import java.util.*;

public class Lab_7_1{

   
    public static void main(String args[]){
        // Scanner sc =  new Scanner(System.in);

        // String name = sc.nextLine();
        // sc.close();

        HashMap<Integer,String> hMap = new HashMap<Integer,String>();
        hMap.put(101,"asd");
        hMap.put(103,"sd");
        hMap.put(102,"ad");

        System.out.println(hMap);
    }
}
